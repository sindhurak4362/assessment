follow the steps to start the project

npm install 

npm start

Note: The API won’t work with CORS enabled, it is suggested to run the app with Chrome in web-securityOFF mode (see link below) or proxy calls through NodeJs/Express
https://alfilatov.com/posts/run-chrome-without-cors/


for windows open cmd and run this command below

"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --disable-web-security --disable-gpu --user-data-dir=~/chromeTemp

it will open chrome with web-securityOFF mode the go to http://localhost:3000/